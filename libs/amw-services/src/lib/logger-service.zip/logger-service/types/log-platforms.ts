export enum LogPlatforms {
  CONSOLE = 'Console',
  SPLUNK = 'Splunk',
}
