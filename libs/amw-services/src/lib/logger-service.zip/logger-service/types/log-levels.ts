export enum LogLevels {
  INFO = 'info',

  DEBUG = 'debug',

  WARN = 'warn',

  ERROR = 'error',
}
